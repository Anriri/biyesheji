@echo off
setlocal
cd /d "%~dp0"
call "%~dp0Use-Project-Cache.bat"
if errorlevel 1 (
 echo Cannot create the project cache. Check disk space and write permissions.
 pause
 exit /b 1
)
echo PROTOCOL ONLY: no AI images will be generated.
py -3.10 -c "import sys;print(sys.version)"
if errorlevel 1 goto fail
if not exist ".venv-api\Scripts\python.exe" py -3.10 -m venv .venv-api
if errorlevel 1 goto fail
".venv-api\Scripts\python.exe" -m pip install -r realtime\backend\requirements-api.txt
if errorlevel 1 goto fail
".venv-api\Scripts\python.exe" launch.py --protocol
pause
exit /b 0
:fail
echo Install Python 3.10 x64 first. Read the error above.
pause
exit /b 1
