@echo off
setlocal
cd /d "%~dp0"
call "%~dp0Use-Project-Cache.bat"
if errorlevel 1 (
 echo Cannot create the project cache. Check disk space and write permissions.
 pause
 exit /b 1
)
if not exist ".venv-gpu\Scripts\python.exe" goto setup
".venv-gpu\Scripts\python.exe" -c "import torch,fastapi,diffusers,streamdiffusion;raise SystemExit(0 if torch.cuda.is_available() else 1)"
if errorlevel 1 goto invalid_env
".venv-gpu\Scripts\python.exe" launch.py
set "RP_EXIT=%errorlevel%"
pause
exit /b %RP_EXIT%
:invalid_env
echo Dependencies or CUDA failed. Read the error above. Run Install-and-Start.bat manually to repair.
pause
exit /b 1
:setup
call Install-and-Start.bat
exit /b %errorlevel%
