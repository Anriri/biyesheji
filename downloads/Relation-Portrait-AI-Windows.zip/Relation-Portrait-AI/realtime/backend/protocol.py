from pydantic import BaseModel, ConfigDict, Field
from typing import Literal

class Control(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False, strict=True)
    type: Literal['control'] = 'control'
    seq: int = Field(ge=0)
    x: float = Field(ge=0, le=1)
    y: float = Field(ge=0, le=1)
    openness: float = Field(ge=0, le=1)
    hand_present: bool
    source: Literal['mediapipe', 'manual']


def prompt_for(c: Control) -> str:
    shape = 'wide open canopy' if c.openness >= .65 else 'half open canopy' if c.openness >= .3 else 'folded narrow canopy'
    return f'a single floating translucent umbrella, {shape}, pearl and pale blue, surreal art photograph, quiet plain background, delicate fabric'


def guide_for(c: Control):
    # Conditioning image only. This is NEVER sent as an AI-generated output frame.
    from PIL import Image, ImageDraw
    import math
    image = Image.new('RGB', (512, 512), '#dfe7e9')
    draw = ImageDraw.Draw(image)
    cx, cy = 90 + c.x * 332, 110 + c.y * 225
    radius = 12 + c.openness * 78
    height = 100 - c.openness * 52
    points = [(cx-radius*math.cos(i*math.pi/40), cy-height*math.sin(i*math.pi/40)) for i in range(41)]
    draw.polygon(points + [(cx+radius,cy),(cx-radius,cy)], fill='#f5f4ed', outline='#6b8193')
    for offset in [-.6, 0, .6]:
        draw.line([(cx,cy-height),(cx+offset*radius,cy)], fill='#91a5b2', width=2)
    draw.line([(cx,cy-height-6),(cx,cy+105)],fill='#526d85',width=4)
    draw.arc((cx,cy+90,cx+27,cy+119),0,180,fill='#526d85',width=4)
    return image
