"""Serial, cache-preserving downloads for the verified default Diffusers repository."""
import hashlib
import time
from pathlib import Path

REPO = 'KBlueLeaf/kohaku-v2.1'
REVISION = '0d9ad923d447081af3db92005e14718509af5fda'
FILES = (
    'model_index.json', 'feature_extractor/preprocessor_config.json',
    'scheduler/scheduler_config.json', 'tokenizer/merges.txt',
    'tokenizer/special_tokens_map.json', 'tokenizer/tokenizer_config.json',
    'tokenizer/vocab.json', 'text_encoder/config.json', 'text_encoder/pytorch_model.bin',
    'vae/config.json', 'vae/diffusion_pytorch_model.bin',
    'safety_checker/config.json', 'safety_checker/pytorch_model.bin',
    'unet/config.json', 'unet/diffusion_pytorch_model.bin',
)
# Authoritative LFS SHA256 values from the pinned official repository metadata.
CHECKSUMS = {
 'safety_checker/pytorch_model.bin': (1216062333, '753acd54aa6d288d6c0ce9d51468eb28f495fcbaacf0edf755fa5fc7ce678cd9'),
 'text_encoder/pytorch_model.bin': (492306077, 'adefbea645231e2e940f24382d5484b34f4dcc503e0a50d090e87f3a40123a7f'),
 'unet/diffusion_pytorch_model.bin': (3438366373, 'f2888df677ed974eef5f71f1c3dcd8c335f16e741bb3408c699a1479e87c0b10'),
 'vae/diffusion_pytorch_model.bin': (334712113, '171bc68795e9a94dd11899fd9b9eba8eea5cd1bd7c912a27c0821bb177684e9f'),
}

def transient(error):
    # Only transport failures are retried. Auth, missing files and integrity errors fail closed.
    return type(error).__name__ in {'ChunkedEncodingError','ConnectionError','ReadTimeout','ConnectTimeout','ProxyError','Timeout'}

def retry_download(operation, report, attempts=5, sleep=time.sleep):
    for attempt in range(1, attempts+1):
        try:
            return operation()
        except Exception as error:
            if not transient(error) or attempt == attempts:
                raise
            report(f'下载连接中断（{type(error).__name__}）；保留缓存，准备第 {attempt+1}/{attempts} 次尝试。')
            sleep(min(2**attempt, 15))


def download_default_model(report, downloader=None, files=FILES, checksums=CHECKSUMS, sleep=time.sleep):
    if downloader is None:
        from huggingface_hub import hf_hub_download
        downloader = hf_hub_download
    root = None
    for index, name in enumerate(files, 1):
        label=f'阶段 2/5：串行准备 {index}/{len(files)} · {name}'
        report(label)
        def operation():
            report(label+'（复用已有缓存/续传；具体字节进度见启动窗口）')
            return downloader(repo_id=REPO, revision=REVISION, filename=name)
        path=Path(retry_download(operation,report,sleep=sleep))
        if name=='model_index.json': root=path.parent
        if name in checksums:
            expected_size, expected_hash=checksums[name]
            report(label+' · 正在检查文件大小与 SHA256，请等待磁盘读取。')
            if path.stat().st_size != expected_size:
                raise ValueError(f'{name} 大小校验失败；缓存已保留，停止模型加载。')
            digest=hashlib.sha256()
            with path.open('rb') as handle:
                for chunk in iter(lambda:handle.read(4*1024*1024), b''): digest.update(chunk)
            if digest.hexdigest()!=expected_hash:
                raise ValueError(f'{name} SHA256 校验失败；不使用受影响权重，不修改预期校验值。')
    if root is None: raise ValueError('Model index missing')
    return str(root)
