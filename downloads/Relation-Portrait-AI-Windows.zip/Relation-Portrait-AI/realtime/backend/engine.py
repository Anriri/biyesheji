import os
from io import BytesIO
from .protocol import Control, guide_for, prompt_for
from .downloads import REPO, download_default_model, retry_download

class PlaceholderEngine:
    state = 'placeholder'
    detail = 'StreamDiffusion 未启用。控制参数可往返，但不会返回任何生成图像。'
    def load(self): pass
    def render(self, control: Control) -> bytes:
        raise RuntimeError('Placeholder never generates frames')

class StreamDiffusionEngine:
    """Official img2img API adapter. All calls run on the same single executor thread."""
    state = 'loading'
    detail = '正在检查 CUDA 并加载真实模型，首次可能下载权重。'
    def load(self):
        self.detail = "阶段 1/5：检查 PyTorch 与 CUDA。"
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError('CUDA GPU 不可用；需要受支持的 NVIDIA GPU 和 CUDA 版 PyTorch。')
        from diffusers import StableDiffusionPipeline, AutoencoderTiny
        from streamdiffusion import StreamDiffusion
        self.torch = torch
        model = os.getenv('SD_MODEL', 'KBlueLeaf/kohaku-v2.1')
        self.detail = '阶段 2/5：下载或读取 SD 基础模型权重（首次可能数 GB），请查看启动窗口进度。'
        def report(message):
            self.detail=message
            print(message,flush=True)
        if model==REPO:
            model_path=download_default_model(report)
            report('阶段 2/5：15 个必要文件已准备并验证，正在从本地缓存载入模型。')
            pipe=StableDiffusionPipeline.from_pretrained(model_path,torch_dtype=torch.float16,local_files_only=True,use_safetensors=False).to('cuda')
        else:
            pipe=retry_download(lambda:StableDiffusionPipeline.from_pretrained(model,torch_dtype=torch.float16),report).to('cuda')
        self.stream = StreamDiffusion(pipe, t_index_list=[32,45], torch_dtype=torch.float16,
                                      use_denoising_batch=False, frame_buffer_size=1, cfg_type='none')
        self.detail = '阶段 3/5：下载或读取 LCM LoRA。'
        retry_download(lambda:self.stream.load_lcm_lora(os.getenv('LCM_LORA', 'latent-consistency/lcm-lora-sdv1-5')),report)
        self.stream.fuse_lora()
        self.detail = '阶段 4/5：下载或读取 Tiny VAE。'
        self.stream.vae = retry_download(lambda:AutoencoderTiny.from_pretrained(os.getenv('TINY_VAE', 'madebyollin/taesd')),report).to(device='cuda',dtype=torch.float16)
        base = Control(seq=0,x=.5,y=.5,openness=.5,hand_present=False,source='manual')
        self.last_prompt = prompt_for(base)
        self.stream.prepare(self.last_prompt, guidance_scale=1.0, seed=int(os.getenv('SD_SEED','42')))
        self.detail = '阶段 5/5：执行真实 CUDA 推理预热；成功后才会标记 ready。'
        self.render(base)  # Real warm-up: readiness requires an actual inference.
        self.state = 'ready'
        self.detail = f'StreamDiffusion img2img 已加载：{model}；未启用 TensorRT，帧率取决于 GPU。'
    def render(self, control: Control) -> bytes:
        from streamdiffusion.image_utils import postprocess_image
        prompt = prompt_for(control)
        with self.torch.inference_mode():
            if prompt != self.last_prompt:
                self.stream.update_prompt(prompt)
                self.last_prompt = prompt
            output = self.stream(guide_for(control))
            image = postprocess_image(output, output_type='pil')[0]
        buf = BytesIO()
        image.convert('RGB').save(buf, format='JPEG', quality=85)
        return buf.getvalue()


def make_engine():
    mode = os.getenv('STREAM_MODE', 'placeholder')
    if mode == 'placeholder': return PlaceholderEngine()
    if mode == 'streamdiffusion': return StreamDiffusionEngine()
    raise ValueError('STREAM_MODE must be placeholder or streamdiffusion')
