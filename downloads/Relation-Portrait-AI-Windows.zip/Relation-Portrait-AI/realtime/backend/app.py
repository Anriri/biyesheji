import asyncio, json, os, time, logging
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager, suppress
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from pydantic import ValidationError
from .engine import make_engine
from .protocol import Control

log = logging.getLogger('realtime')

def create_app(engine=None):
    engine = engine or make_engine()
    @asynccontextmanager
    async def lifespan(app):
        pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix='streamdiffusion')
        app.state.pool, app.state.active = pool, False
        async def load():
            try: await asyncio.get_running_loop().run_in_executor(pool, engine.load)
            except Exception as e:
                log.exception('StreamDiffusion initialization failed')
                kind=type(e).__name__
                if kind in {'ReadTimeout','ConnectTimeout','ConnectionError','ProxyError','SSLError','ChunkedEncodingError'}:
                    reason='模型下载连接失败或超时。请检查代理能否访问 Hugging Face 及其 CDN；缓存已保留，恢复网络后重启后端。'
                elif kind=='OutOfMemoryError':
                    reason='GPU 显存不足，请关闭占用显存的程序后重启。'
                else:
                    reason=f'加载失败：{kind}。请查看启动窗口的完整错误。'
                engine.state,engine.detail='unavailable',engine.detail+' '+reason
        loading = asyncio.create_task(load())
        yield
        loading.cancel()
        with suppress(asyncio.CancelledError): await loading
        pool.shutdown(wait=True, cancel_futures=True)
    app = FastAPI(title='Relation Portrait realtime prototype',lifespan=lifespan)
    def status(): return {'type':'status','protocol':1,'engine':engine.state,'detail':engine.detail,'real_inference':engine.state=='ready'}
    @app.get('/api/health')
    async def health(): return status()

    @app.websocket('/api/ws')
    async def ws(socket: WebSocket):
        allowed = os.getenv('ALLOWED_ORIGINS','http://localhost:5174,http://127.0.0.1:5174,http://localhost:8000,http://127.0.0.1:8000').split(',')
        if socket.headers.get('origin') and socket.headers['origin'] not in allowed:
            await socket.close(code=1008); return
        await socket.accept()
        if app.state.active:
            await socket.send_json({'type':'error','detail':'已有一个客户端占用最小原型，请先断开它。'})
            await socket.close(code=1013); return
        app.state.active=True
        latest=None; last_seq=-1; pending_error=None; event=asyncio.Event(); ack=asyncio.Event(); awaiting=None
        async def receive():
            nonlocal latest,last_seq,pending_error,awaiting
            while True:
                text=await socket.receive_text()
                if len(text)>4096: raise ValueError('Control packet too large')
                try:
                    data=json.loads(text)
                    if isinstance(data,dict) and data.get('type')=='ack':
                        if data.get('frame_id')==awaiting: ack.set()
                        continue
                    control=Control.model_validate(data)
                    if control.seq<=last_seq: raise ValueError('seq must increase')
                    latest,last_seq=control,control.seq
                except (ValueError,TypeError,ValidationError): pending_error='无效参数：需要递增 seq、0–1 有限数值及正确字段。'
                event.set()
        async def send():
            nonlocal pending_error,awaiting
            frame_id=0; last_control_sent=-1; last_status=None
            while True:
                current=status()
                if current!=last_status:
                    await socket.send_json(current); last_status=current
                if pending_error:
                    await socket.send_json({'type':'error','detail':pending_error});pending_error=None
                control=latest
                if control and control.seq!=last_control_sent:
                    await socket.send_json({'type':'control_ack','control':control.model_dump()});last_control_sent=control.seq
                if engine.state=='ready' and control:
                    started=time.perf_counter()
                    try:
                        jpeg=await asyncio.get_running_loop().run_in_executor(app.state.pool,engine.render,control)
                        if not isinstance(jpeg,bytes) or not jpeg.startswith(b'\xff\xd8'): raise RuntimeError('Engine did not return JPEG')
                    except Exception:
                        log.exception('Inference failed');engine.state='unavailable';engine.detail='真实推理失败，已停止图像输出。检查后端日志后重启服务。';continue
                    frame_id+=1;awaiting=frame_id;ack.clear()
                    await socket.send_json({'type':'frame','frame_id':frame_id,'seq':control.seq,'mime':'image/jpeg','inference_ms':round((time.perf_counter()-started)*1000,1),'control':control.model_dump(),'real_inference':True})
                    await socket.send_bytes(jpeg)
                    # At most one image is in flight. New controls overwrite the mailbox.
                    await asyncio.wait_for(ack.wait(),timeout=15)
                    await asyncio.sleep(max(0,1/max(1,float(os.getenv('MAX_FPS','8')))-(time.perf_counter()-started)))
                else:
                    event.clear()
                    with suppress(asyncio.TimeoutError): await asyncio.wait_for(event.wait(),timeout=.5)
        tasks=[asyncio.create_task(receive()),asyncio.create_task(send())]
        try:
            done,_=await asyncio.wait(tasks,return_when=asyncio.FIRST_COMPLETED)
            for t in done: t.result()
        except (WebSocketDisconnect,asyncio.TimeoutError,ValueError,RuntimeError): pass
        finally:
            for t in tasks: t.cancel()
            for t in tasks:
                with suppress(asyncio.CancelledError,WebSocketDisconnect,ValueError,RuntimeError,asyncio.TimeoutError): await t
            # Wait for an in-flight CUDA call before allowing another owner.
            await asyncio.get_running_loop().run_in_executor(app.state.pool,lambda:None)
            app.state.active=False
            with suppress(RuntimeError): await socket.close()
    static_dir=os.getenv('AI_STATIC_DIR')
    if static_dir:
        from fastapi.staticfiles import StaticFiles
        app.mount('/',StaticFiles(directory=static_dir,html=True),name='frontend')
    return app

app=create_app()
