import http.client, os, pathlib, socket, subprocess, sys, threading, time, webbrowser
root=pathlib.Path(__file__).resolve().parent
try:
 with socket.socket() as s:s.bind(('127.0.0.1',8000))
except OSError:
 print('Port 8000 is occupied. Close your previous prototype window and retry.');sys.exit(1)
env=os.environ.copy();env['STREAM_MODE']='placeholder' if '--protocol' in sys.argv else 'streamdiffusion';env['AI_STATIC_DIR']=str(root/'web')
proc=subprocess.Popen([sys.executable,'-m','uvicorn','realtime.backend.app:app','--host','127.0.0.1','--port','8000','--ws-max-size','8192'],cwd=root,env=env)
def open_page():
 for _ in range(90):
  if proc.poll() is not None:return
  try:
   c=http.client.HTTPConnection('127.0.0.1',8000,timeout=1);c.request('GET','/api/health');r=c.getresponse();ready=r.status==200;r.read();c.close()
   if ready:webbrowser.open('http://localhost:8000');print('Page opened. Click Connect Backend. ready + received frames is required for real inference.');return
  except OSError:pass
  time.sleep(.5)
 print('Service not reachable. Read the error in this window.')
threading.Thread(target=open_page,daemon=True).start()
try:sys.exit(proc.wait())
except KeyboardInterrupt:
 proc.terminate();proc.wait()
