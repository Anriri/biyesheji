@echo off
setlocal
cd /d "%~dp0"
call "%~dp0Use-Project-Cache.bat"
if errorlevel 1 (
 echo Cannot create the project cache. Check disk space and write permissions.
 pause
 exit /b 1
)
where py >nul 2>&1
if errorlevel 1 goto python_missing
py -3.10 -c "import sys;print(sys.version)"
if errorlevel 1 goto python_missing
where git >nul 2>&1
if errorlevel 1 goto git_missing
where nvidia-smi >nul 2>&1
if errorlevel 1 (
 if not exist "%ProgramFiles%\NVIDIA Corporation\NVSMI\nvidia-smi.exe" goto no_cuda
 "%ProgramFiles%\NVIDIA Corporation\NVSMI\nvidia-smi.exe" -L
) else (
 nvidia-smi -L
)
if errorlevel 1 goto no_cuda
if not exist ".venv-gpu\Scripts\python.exe" py -3.10 -m venv .venv-gpu
if errorlevel 1 goto fail
".venv-gpu\Scripts\python.exe" -m pip install --upgrade pip==25.3 setuptools==75.8.2 wheel==0.45.1 --index-url https://pypi.org/simple
if errorlevel 1 goto fail
".venv-gpu\Scripts\python.exe" -m pip install -r realtime\backend\requirements-torch-base.txt --index-url https://pypi.org/simple
if errorlevel 1 goto fail
".venv-gpu\Scripts\python.exe" -m pip install torch==2.1.0+cu121 torchvision==0.16.0+cu121 --index-url https://download.pytorch.org/whl/cu121
if errorlevel 1 goto fail
".venv-gpu\Scripts\python.exe" -m pip install -r realtime\backend\requirements-stream.txt --index-url https://pypi.org/simple
if errorlevel 1 goto fail
".venv-gpu\Scripts\python.exe" -c "import torch;print('CUDA:',torch.cuda.is_available());raise SystemExit(0 if torch.cuda.is_available() else 1)"
if errorlevel 1 goto no_cuda
call Start.bat
exit /b %errorlevel%
:python_missing
echo Install Python 3.10 x64 with the py launcher. Reopen this script after installation.
echo https://www.python.org/ftp/python/3.10.11/python-3.10.11-amd64.exe
goto fail
:git_missing
echo Install Git for Windows, reopen this script: https://git-scm.com/downloads/win
goto fail
:no_cuda
echo NVIDIA driver or CUDA PyTorch is not usable. No fake images will be returned.
echo You can separately run Start-Protocol-Test.bat to test controls without AI inference.
:fail
echo Setup failed. Keep the error text above for troubleshooting.
pause
exit /b 1
