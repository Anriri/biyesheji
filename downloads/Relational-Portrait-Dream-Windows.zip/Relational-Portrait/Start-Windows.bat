@echo off
cd /d "%~dp0"
runtime\node.exe serve.cjs
pause
