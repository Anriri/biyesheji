@echo off
rem Session-only settings; no registry changes and no deletion of existing files.
set "RP_CACHE=%~dp0cache"
if not exist "%RP_CACHE%\tmp" mkdir "%RP_CACHE%\tmp"
if errorlevel 1 exit /b 1
if not exist "%RP_CACHE%\huggingface" mkdir "%RP_CACHE%\huggingface"
if errorlevel 1 exit /b 1
if not exist "%RP_CACHE%\torch" mkdir "%RP_CACHE%\torch"
if errorlevel 1 exit /b 1
set "TEMP=%RP_CACHE%\tmp"
set "TMP=%RP_CACHE%\tmp"
set "TMPDIR=%RP_CACHE%\tmp"
set "PIP_NO_CACHE_DIR=1"
set "PIP_CACHE_DIR=%RP_CACHE%\pip"
set "HF_HOME=%RP_CACHE%\huggingface"
set "HF_HUB_CACHE=%HF_HOME%\hub"
set "HUGGINGFACE_HUB_CACHE=%HF_HOME%\hub"
set "TRANSFORMERS_CACHE=%HF_HOME%\hub"
set "TORCH_HOME=%RP_CACHE%\torch"
set "XDG_CACHE_HOME=%RP_CACHE%"
set "HF_HUB_DOWNLOAD_TIMEOUT=120"
set "HF_HUB_ETAG_TIMEOUT=60"
echo Model download timeout: 120 seconds.
echo Downloads and temporary files use: %RP_CACHE%
exit /b 0
